# ============================================================
# Exploratory Analysis of Google Play Store Apps using R
# Data Analytics Lab - CA3 Mini Project
# Dataset: googleplaystore.csv (Kaggle, 10,841 rows x 13 columns)
# ============================================================

# ---- Section 1: Setup & Load (Lab 1, Data Structures & I/O) ----
suppressPackageStartupMessages({
  library(ggplot2)
  library(writexl)
  library(dplyr)
})
invisible(suppressWarnings(Sys.setlocale("LC_TIME", "C")))  # English month names

# Use the folder this script is saved in as the working directory (RStudio)
try(if (requireNamespace("rstudioapi", quietly = TRUE) && rstudioapi::isAvailable()) {
  setwd(dirname(rstudioapi::getSourceEditorContext()$path))
}, silent = TRUE)
cat("Working directory:", getwd(), "\n")

dir.create("plots",  showWarnings = FALSE)
dir.create("output", showWarnings = FALSE)

# Find the CSV: same folder as the script, or inside a data/ folder
csv_path <- c("googleplaystore.csv", "data/googleplaystore.csv")
csv_path <- csv_path[file.exists(csv_path)][1]
if (is.na(csv_path)) stop("googleplaystore.csv not found. Put it in this folder: ", getwd())

# Draw each ggplot in the RStudio Plots panel AND save it to the plots/ folder
ggsave_show <- function(filename, plot, ...) {
  print(plot)
  ggplot2::ggsave(filename, plot, ...)
}

# Draw a base-R plot in the Plots panel AND save it as a PNG
base_show_save <- function(filename, width, height, expr) {
  code <- substitute(expr)
  eval(code, parent.frame())                                  # on screen
  png(filename, width = width, height = height)
  eval(code, parent.frame())                                  # to file
  invisible(dev.off())
}

apps <- read.csv(csv_path, stringsAsFactors = FALSE, check.names = FALSE)
names(apps) <- c("app", "category", "rating", "reviews", "size", "installs", "type",
                 "price", "content_rating", "genres", "last_updated", "current_ver",
                 "android_ver")

cat("Class:", class(apps), "\n")
cat("Dimensions:", dim(apps), "\n\n")
cat("Structure:\n"); str(apps)
cat("\nFirst rows:\n"); print(head(apps))
cat("\nNA count per column:\n"); print(colSums(is.na(apps)))
cat("\nBlank-string count per column:\n"); print(colSums(apps == "", na.rm = TRUE))
cat("\nUnique values - type:\n"); print(table(apps$type, useNA = "ifany"))
cat("\nSample size values:\n"); print(head(unique(apps$size), 15))
cat("\nSample installs values:\n"); print(head(unique(apps$installs), 10))
cat("\nNon-numeric price samples:\n"); print(head(unique(apps$price[apps$price != "0"]), 8))
cat("\nDuplicate rows:", sum(duplicated(apps)),
    "| duplicated app names:", sum(duplicated(apps$app)), "\n")

# Lab 1: arithmetic / relational / logical operators on the data
cat("\nLab 1 - operators on the data:\n")
n_apps  <- nrow(apps)
n_paid  <- sum(apps$type == "Paid", na.rm = TRUE)
cat("Paid share (%):", round(n_paid / n_apps * 100, 2), "\n")
cat("Apps rated above 4.0:", sum(apps$rating > 4, na.rm = TRUE), "\n")
cat("Rated above 4 AND paid:", sum(apps$rating > 4 & apps$type == "Paid", na.rm = TRUE), "\n")

# Raw missingness map (built with ggplot2 so no extra package is needed)
miss_df <- data.frame(
  variable = rep(names(apps), each = nrow(apps)),
  row      = rep(seq_len(nrow(apps)), times = ncol(apps)),
  missing  = as.vector(is.na(apps) | apps == "")
)
miss_df$variable <- factor(miss_df$variable, levels = names(apps))
g_miss <- ggplot(miss_df, aes(variable, row, fill = missing)) +
  geom_raster() +
  scale_y_reverse() +
  scale_fill_manual(values = c("FALSE" = "#98C1D9", "TRUE" = "#EE6C4D"),
                    labels = c("Present", "Missing")) +
  labs(title = "Missing Values in Raw Dataset", x = NULL, y = "Row", fill = NULL) +
  theme_minimal(base_size = 13) +
  theme(axis.text.x = element_text(angle = 40, hjust = 1))
ggsave_show("plots/01_missing_raw.png", g_miss, width = 9, height = 6, dpi = 150)
raw_rows <- nrow(apps)
raw_missing_cells <- sum(is.na(apps) | apps == "")
cat("Raw missing cells:", raw_missing_cells, "| % of all cells:",
    round(raw_missing_cells / (nrow(apps) * ncol(apps)) * 100, 2), "\n")

# ---- Section 2: Data Cleaning (Lab 3 control flow + Lab 4 missing values) ----
cat("\n================ SECTION 2: CLEANING ================\n")

# 2.1 Malformed record: one row has its columns shifted (Category = "1.9")
bad_row <- apps$category == "1.9"
cat("Malformed row(s) with Category = '1.9':", sum(bad_row), "\n")
print(apps[bad_row, c("app", "category", "rating", "reviews")])
apps <- apps[!bad_row, ]

# 2.2 Blank strings -> NA, trim whitespace
apps[] <- lapply(apps, function(col) {
  if (is.character(col)) {
    col <- trimws(gsub("\\s+", " ", col))
    col[col == ""] <- NA
  }
  col
})
apps$type[apps$type == "NaN"] <- NA
cat("Missing values after blank->NA conversion:\n"); print(colSums(is.na(apps)))

# 2.3 Duplicates: exact duplicate rows, then one row per app name
n_exact <- sum(duplicated(apps))
apps <- apps[!duplicated(apps), ]
cat("\nExact duplicate rows removed:", n_exact, "\n")
apps$reviews_num <- suppressWarnings(as.numeric(apps$reviews))
apps <- apps[order(apps$app, -apps$reviews_num), ]      # most-reviewed copy first
n_dup_name <- sum(duplicated(apps$app))
apps <- apps[!duplicated(apps$app), ]
cat("Repeated app names removed (kept most-reviewed copy):", n_dup_name, "\n")

# 2.4 Numeric conversions
apps$reviews  <- apps$reviews_num
apps$reviews_num <- NULL
apps$installs <- as.numeric(gsub("[+,]", "", apps$installs))
apps$price    <- as.numeric(gsub("\\$", "", apps$price))

# size -> MB, unit handled with switch() inside a for loop (Lab 3)
convert_size <- function(x) {
  if (is.na(x) || x == "Varies with device") return(NA_real_)
  unit  <- substr(x, nchar(x), nchar(x))
  value <- suppressWarnings(as.numeric(substr(x, 1, nchar(x) - 1)))
  factor <- switch(unit, "M" = 1, "k" = 1 / 1024, "K" = 1 / 1024, "G" = 1024, NA)
  if (is.na(factor)) cat("Unknown size unit:", x, "\n")
  value * factor
}
size_clean <- numeric(nrow(apps))
for (i in seq_len(nrow(apps))) {
  size_clean[i] <- convert_size(apps$size[i])
}
cat("Size 'Varies with device' / unparseable ->", sum(is.na(size_clean)), "NA\n")
apps$size_mb <- round(size_clean, 3)
apps$size <- NULL

# dates
apps$last_updated <- as.Date(apps$last_updated, format = "%B %d, %Y")
snapshot <- max(apps$last_updated)
apps$days_since_update <- as.numeric(snapshot - apps$last_updated)
cat("Dataset snapshot date (latest update):", format(snapshot), "\n")

# 2.5 Rating validity
cat("Ratings outside [1, 5]:", sum(apps$rating < 1 | apps$rating > 5, na.rm = TRUE), "\n")
cat("Rating is NA for", sum(is.na(apps$rating)), "apps; of those,",
    sum(is.na(apps$rating) & apps$reviews > 0, na.rm = TRUE), "have >= 1 review and",
    sum(is.na(apps$rating) & apps$reviews <= 5, na.rm = TRUE), "have <= 5 reviews\n")

# 2.6 Imputation (Lab 4)
#   rating is NOT imputed: a missing rating means the app has too few reviews to be rated,
#   so a filled-in value would be invented. Rating analysis uses rated apps only.
type_mode <- names(which.max(table(apps$type)))
apps$type[is.na(apps$type)] <- type_mode
cat("Imputed type with mode =", type_mode, "\n")
apps$content_rating[is.na(apps$content_rating)] <-
  names(which.max(table(apps$content_rating)))
size_median <- median(apps$size_mb, na.rm = TRUE)
apps$size_mb_imp <- apps$size_mb
apps$size_mb_imp[is.na(apps$size_mb_imp)] <- size_median
cat("Imputed size_mb_imp with median =", size_median, "MB\n")
apps$genres[is.na(apps$genres)] <- apps$category[is.na(apps$genres)]

# 2.7 Factors
apps$category       <- factor(apps$category)
apps$type           <- factor(apps$type, levels = c("Free", "Paid"))
apps$content_rating <- factor(apps$content_rating)

# 2.8 Derived feature: engagement = reviews per 1,000 installs (installs is a lower-bound bin)
apps$review_rate <- round(apps$reviews / apps$installs * 1000, 3)
apps$review_rate[is.infinite(apps$review_rate)] <- NA

# 2.9 Domain rule: novelty "I am rich"-style apps priced above $100
before <- nrow(apps)
cat("\nApps priced above $100:", sum(apps$price > 100), "\n")
print(apps[apps$price > 100, c("app", "price")][1:5, ])
apps <- apps[apps$price <= 100, ]
cat("Rows removed by price <= $100 rule:", before - nrow(apps), "\n")

# 2.10 Verify
cat("\nRows: raw =", raw_rows, "| clean =", nrow(apps),
    "| removed =", raw_rows - nrow(apps), "(",
    round((raw_rows - nrow(apps)) / raw_rows * 100, 1), "% )\n")
cat("Missing values per column (clean):\n"); print(colSums(is.na(apps)))
str(apps)
print(summary(apps[, c("rating", "reviews", "installs", "price", "size_mb", "days_since_update")]))

# ---- Section 2B: Outlier Flagging ----
cat("\n================ SECTION 2B: OUTLIERS ================\n")
# Popularity outliers are the signal of this dataset, so they are FLAGGED, not removed.
apps$log_reviews  <- log10(apps$reviews + 1)
apps$log_installs <- log10(apps$installs + 1)
apps$is_outlier <- FALSE
for (cat_name in levels(apps$category)) {          # per-category IQR (Lab 3 loop + Lab 5 boxplot logic)
  idx <- which(apps$category == cat_name)
  q   <- quantile(apps$log_reviews[idx], c(0.25, 0.75))
  iqr <- q[2] - q[1]
  apps$is_outlier[idx] <- apps$log_reviews[idx] < q[1] - 1.5 * iqr |
                          apps$log_reviews[idx] > q[2] + 1.5 * iqr
}
cat("Apps flagged as review-count outliers within their category:", sum(apps$is_outlier),
    "(", round(mean(apps$is_outlier) * 100, 1), "% ) - retained\n")
cat("Final clean rows:", nrow(apps), "\n")

# ---- Section 3: Transformation & Feature Engineering (Lab 2, 3, 4) ----
cat("\n================ SECTION 3: TRANSFORMATION ================\n")
skewness <- function(x) { x <- x[!is.na(x)]; mean((x - mean(x))^3) / sd(x)^3 }

# 3.1 Log transform (Lab 4)
cat("Skewness reviews:", round(skewness(apps$reviews), 2),
    "| log10(reviews+1):", round(skewness(apps$log_reviews), 2), "\n")
cat("Skewness installs:", round(skewness(apps$installs), 2),
    "| log10(installs+1):", round(skewness(apps$log_installs), 2), "\n")

# 3.2 Z-score standardisation (Lab 4)
apps$size_z <- as.numeric(scale(apps$size_mb_imp))
cat("size_z mean:", round(mean(apps$size_z), 4), "| sd:", round(sd(apps$size_z), 4), "\n")

# 3.3 Min-max normalisation (Lab 4)
minmax <- function(x) (x - min(x, na.rm = TRUE)) / (max(x, na.rm = TRUE) - min(x, na.rm = TRUE))
apps$rating_norm <- minmax(apps$rating)
cat("rating_norm range:", range(apps$rating_norm, na.rm = TRUE), "\n")

# 3.4 Install tier via if-else ladder (Lab 3)
classify_installs <- function(n) {
  if (n < 10000) {
    "Low (<10K)"
  } else if (n < 1000000) {
    "Medium (10K-1M)"
  } else if (n < 100000000) {
    "High (1M-100M)"
  } else {
    "Mega (100M+)"
  }
}
apps$install_tier <- factor(sapply(apps$installs, classify_installs),
                            levels = c("Low (<10K)", "Medium (10K-1M)", "High (1M-100M)", "Mega (100M+)"))
cat("\nInstall tier distribution:\n"); print(table(apps$install_tier))

classify_rating <- function(r) {
  if (is.na(r)) {
    "Not rated"
  } else if (r >= 4.5) {
    "Excellent"
  } else if (r >= 4.0) {
    "Good"
  } else if (r >= 3.0) {
    "Average"
  } else {
    "Poor"
  }
}
apps$rating_group <- factor(sapply(apps$rating, classify_rating),
                            levels = c("Excellent", "Good", "Average", "Poor", "Not rated"))
cat("\nRating group distribution:\n"); print(table(apps$rating_group))

# 3.5 Broad category group via switch() with fall-through (Lab 3)
group_category <- function(cat_name) {
  switch(cat_name,
         "GAME" = "Games",
         "FAMILY" = , "PARENTING" = , "COMICS" = "Family & Kids",
         "TOOLS" = , "PRODUCTIVITY" = , "COMMUNICATION" = , "PERSONALIZATION" = ,
         "LIBRARIES_AND_DEMO" = "Tools & Productivity",
         "SOCIAL" = , "DATING" = , "LIFESTYLE" = , "PHOTOGRAPHY" = , "ENTERTAINMENT" = ,
         "VIDEO_PLAYERS" = , "SPORTS" = , "ART_AND_DESIGN" = , "EVENTS" = , "BEAUTY" = ,
         "FOOD_AND_DRINK" = , "HOUSE_AND_HOME" = , "SHOPPING" = "Lifestyle & Entertainment",
         "HEALTH_AND_FITNESS" = , "MEDICAL" = , "EDUCATION" = , "BOOKS_AND_REFERENCE" = ,
         "NEWS_AND_MAGAZINES" = "Health, Education & Info",
         "FINANCE" = , "BUSINESS" = "Finance & Business",
         "TRAVEL_AND_LOCAL" = , "MAPS_AND_NAVIGATION" = , "AUTO_AND_VEHICLES" = ,
         "WEATHER" = "Travel & Navigation",
         "Other")
}
apps$cat_group <- factor(sapply(as.character(apps$category), group_category))
cat("\nCategory group sizes:\n"); print(sort(table(apps$cat_group), decreasing = TRUE))

# 3.6 Vectors with seq() for size bins (Lab 2)
size_breaks <- c(seq(0, 60, by = 10), Inf)
size_labels <- paste0(head(size_breaks, -1), "-", tail(size_breaks, -1))
apps$size_bin <- cut(apps$size_mb, breaks = size_breaks, labels = size_labels, include.lowest = TRUE)
cat("\nSize bins (MB):\n"); print(table(apps$size_bin, useNA = "ifany"))

# 3.7 Matrix: mean rating by category group x type (Lab 2)
rated <- apps[!is.na(apps$rating), ]
rating_matrix <- round(tapply(rated$rating, list(rated$cat_group, rated$type), mean), 2)
cat("\nMean rating matrix (category group x type):\n"); print(rating_matrix)
cat("Matrix dim:", dim(rating_matrix), "\n")

# 3.8 List summarising the dataset (Data structures lab)
summary_list <- list(
  rows         = nrow(apps),
  categories   = nlevels(apps$category),
  rated_apps   = nrow(rated),
  median_installs = median(apps$installs),
  top_tier     = names(which.max(table(apps$install_tier)))
)
cat("\nSummary list:\n"); str(summary_list)

# ---- Section 4: Exploratory Data Analysis (Lab 5) ----
cat("\n================ SECTION 4: EDA ================\n")

# 4.1 Descriptive statistics (for loop, Lab 5)
num_cols <- c("rating", "reviews", "installs", "price", "size_mb", "days_since_update")
desc_stats <- data.frame()
for (col in num_cols) {
  x <- apps[[col]]; x <- x[!is.na(x)]
  desc_stats <- rbind(desc_stats, data.frame(
    variable = col, n = length(x),
    mean = round(mean(x), 2), median = round(median(x), 2),
    sd = round(sd(x), 2), variance = round(var(x), 2),
    min = min(x), q1 = quantile(x, 0.25, names = FALSE),
    q3 = quantile(x, 0.75, names = FALSE), max = max(x), iqr = IQR(x)))
}
cat("Descriptive statistics:\n"); print(desc_stats, row.names = FALSE)

# 4.2 Correlation matrix (Lab 2 matrix + Lab 5)
cor_vars <- c("rating", "log_reviews", "log_installs", "price", "size_mb", "days_since_update")
cor_matrix <- round(cor(apps[, cor_vars], use = "pairwise.complete.obs"), 3)
cat("\nCorrelation matrix (Pearson, pairwise complete):\n"); print(cor_matrix)
cat("\nSpearman rho: installs vs days_since_update =",
    round(cor(apps$installs, apps$days_since_update, method = "spearman"), 3),
    "| installs vs rating =",
    round(cor(apps$installs, apps$rating, method = "spearman", use = "complete.obs"), 3), "\n")

# 4.3 Category rankings
cat_stats <- apps %>%
  group_by(category) %>%
  summarise(apps = n(),
            rated = sum(!is.na(rating)),
            median_installs = median(installs),
            mean_rating = round(mean(rating, na.rm = TRUE), 3),
            paid_pct = round(mean(type == "Paid") * 100, 1), .groups = "drop") %>%
  arrange(desc(mean_rating))
cat("\nTop 10 categories by mean rating:\n");   print(as.data.frame(head(cat_stats, 10)))
cat("\nBottom 10 categories by mean rating:\n"); print(as.data.frame(tail(cat_stats, 10)))
cat("\nTop 10 categories by app count:\n")
print(as.data.frame(cat_stats %>% arrange(desc(apps)) %>% head(10)))
cat("\nTop 10 categories by median installs:\n")
print(as.data.frame(cat_stats %>% arrange(desc(median_installs)) %>% head(10)))

# 4.4 Group statistics
cat("\nType split:\n"); print(table(apps$type)); print(round(prop.table(table(apps$type)) * 100, 1))
cat("\nMedian installs by type:\n"); print(tapply(apps$installs, apps$type, median))
cat("\nMean / median rating by type (rated apps):\n")
print(round(tapply(apps$rating, apps$type, mean, na.rm = TRUE), 3))
print(round(tapply(apps$rating, apps$type, median, na.rm = TRUE), 3))
cat("\nMedian installs by content rating:\n"); print(tapply(apps$installs, apps$content_rating, median))
cat("\nMean rating by content rating:\n")
print(round(tapply(apps$rating, apps$content_rating, mean, na.rm = TRUE), 3))
cat("\nMean rating by size bin:\n"); print(round(tapply(apps$rating, apps$size_bin, mean, na.rm = TRUE), 3))
cat("\nMedian installs by size bin:\n"); print(tapply(apps$installs, apps$size_bin, median))
cat("\nShare of apps by rating group (%):\n")
print(round(prop.table(table(apps$rating_group)) * 100, 1))
cat("\nShare of apps updated within 180 days of snapshot (%):",
    round(mean(apps$days_since_update <= 180) * 100, 1), "\n")
cat("Median installs: updated <=180 days:", median(apps$installs[apps$days_since_update <= 180]),
    "| > 365 days:", median(apps$installs[apps$days_since_update > 365]), "\n")
cat("Paid apps price: median $", median(apps$price[apps$type == "Paid"]),
    "| mean $", round(mean(apps$price[apps$type == "Paid"]), 2),
    "| share <= $2.99:", round(mean(apps$price[apps$type == "Paid"] <= 2.99) * 100, 1), "%\n")
cat("Free vs paid install-tier mix (%):\n")
print(round(prop.table(table(apps$type, apps$install_tier), 1) * 100, 1))
cat("Price vs rating among paid apps (Pearson r):",
    round(cor(apps$price[apps$type == "Paid"], apps$rating[apps$type == "Paid"],
              use = "complete.obs"), 3), "\n")
cat("Review rate (reviews per 1,000 installs): median",
    median(apps$review_rate, na.rm = TRUE), "\n")
cat("Median review rate by type:\n"); print(tapply(apps$review_rate, apps$type, median, na.rm = TRUE))

cat("\nInstall tier shares (%):\n"); print(round(prop.table(table(apps$install_tier)) * 100, 1))
group_stats <- apps %>%
  group_by(cat_group) %>%
  summarise(apps = n(),
            median_installs = median(installs),
            pct_1M_plus = round(mean(installs >= 1e6) * 100, 1),
            mean_rating = round(mean(rating, na.rm = TRUE), 3),
            paid_pct = round(mean(type == "Paid") * 100, 1), .groups = "drop") %>%
  arrange(desc(median_installs))
cat("\nCategory group summary:\n"); print(as.data.frame(group_stats))
cat("\nShare of apps with 1M+ installs (%): updated <=180 days:",
    round(mean(apps$installs[apps$days_since_update <= 180] >= 1e6) * 100, 1),
    "| updated > 365 days:",
    round(mean(apps$installs[apps$days_since_update > 365] >= 1e6) * 100, 1), "\n")
cat("Share of apps with 1M+ installs (%) by type:\n")
print(round(tapply(apps$installs >= 1e6, apps$type, mean) * 100, 1))
cat("Rated apps with 4.0+ rating (%):",
    round(mean(apps$rating[!is.na(apps$rating)] >= 4) * 100, 1), "\n")
cat("Median reviews of unrated vs rated apps:",
    median(apps$reviews[is.na(apps$rating)]), "vs", median(apps$reviews[!is.na(apps$rating)]), "\n")

# 4.5 Base R plots (shown in the Plots panel and saved as PNG)
base_show_save("plots/02_hist_rating_installs.png", 1000, 600, {
  par(mfrow = c(1, 2))
  hist(apps$rating, breaks = 30, col = "#4C9F9F", border = "white",
       main = "Rating Distribution", xlab = "Rating (1-5)")
  hist(apps$log_installs, breaks = 30, col = "#E07A5F", border = "white",
       main = "Installs Distribution (log10)", xlab = "log10(Installs + 1)")
  par(mfrow = c(1, 1))
})

base_show_save("plots/03_boxplot_rating_tier.png", 900, 600, {
  boxplot(rating ~ install_tier, data = apps, col = "#81B29A",
          main = "Rating by Install Tier", xlab = "Install tier", ylab = "Rating")
})

base_show_save("plots/04_scatter_reviews_installs.png", 900, 600, {
  plot(apps$log_reviews, apps$log_installs, pch = 20, col = rgb(0.3, 0.6, 0.6, 0.3),
       main = "Reviews vs Installs (log10 scale)", xlab = "log10(Reviews + 1)",
       ylab = "log10(Installs + 1)")
  abline(lm(log_installs ~ log_reviews, data = apps), col = "#E07A5F", lwd = 2)
})
cat("\nBase R plots saved to plots/ (02-04)\n")

# ---- Section 5: Visualisation with ggplot2 (Lab 6) ----
cat("\n================ SECTION 5: GGPLOT2 ================\n")
theme_set(theme_minimal(base_size = 13) +
          theme(plot.title = element_text(face = "bold"),
                plot.subtitle = element_text(colour = "grey40")))
pal <- c("#3D5A80", "#98C1D9", "#EE6C4D", "#81B29A")

# 5.1 Scatter + regression line, coloured by type
g1 <- ggplot(apps, aes(log_reviews, log_installs, colour = type)) +
  geom_point(alpha = 0.3, size = 1.1) +
  geom_smooth(method = "lm", formula = y ~ x, se = FALSE, linewidth = 1.1) +
  scale_colour_manual(values = pal[c(1, 3)]) +
  labs(title = "Reviews vs Installs", subtitle = "Both on log10 scale, linear trend by type",
       x = "log10(Reviews + 1)", y = "log10(Installs + 1)", colour = "Type")
ggsave_show("plots/05_gg_scatter_reviews_installs.png", g1, width = 9, height = 6, dpi = 150)

# 5.2 Bar chart: top 10 categories by app count with labels
top10 <- cat_stats %>% arrange(desc(apps)) %>% head(10)
g2 <- ggplot(top10, aes(reorder(category, apps), apps)) +
  geom_col(fill = pal[1]) + coord_flip() +
  geom_text(aes(label = apps), hjust = -0.15) +
  scale_y_continuous(expand = expansion(mult = c(0, 0.12))) +
  labs(title = "Top 10 Categories by Number of Apps", x = NULL, y = "Apps")
ggsave_show("plots/06_gg_bar_categories.png", g2, width = 8, height = 5.5, dpi = 150)

# 5.3 Stacked bar: install tier mix by category group (proportions)
g3 <- ggplot(apps, aes(cat_group, fill = install_tier)) +
  geom_bar(position = "fill") + coord_flip() +
  scale_y_continuous(labels = scales::percent) +
  scale_fill_manual(values = pal) +
  labs(title = "Install Tier Mix by Category Group", x = NULL, y = "Share", fill = "Install tier")
ggsave_show("plots/07_gg_stacked_tier_group.png", g3, width = 9, height = 5.5, dpi = 150)

# 5.4 Grouped bar: median installs by category group x type
grp_df <- apps %>% group_by(cat_group, type) %>%
  summarise(med_installs = median(installs), n = n(), .groups = "drop") %>% filter(n >= 10)
g4 <- ggplot(grp_df, aes(cat_group, med_installs, fill = type)) +
  geom_col(position = "dodge") + coord_flip() +
  scale_y_continuous(labels = scales::comma) +
  scale_fill_manual(values = pal[c(1, 3)]) +
  labs(title = "Median Installs by Category Group and Type",
       subtitle = "Groups with at least 10 apps of that type",
       x = NULL, y = "Median installs", fill = "Type")
ggsave_show("plots/08_gg_grouped_group_type.png", g4, width = 9, height = 5.5, dpi = 150)

# 5.5 Horizontal bar: highest vs lowest rated categories
tb <- rbind(head(cat_stats, 8) %>% mutate(group = "Highest rated"),
            tail(cat_stats, 8) %>% mutate(group = "Lowest rated"))
g5 <- ggplot(tb, aes(reorder(category, mean_rating), mean_rating, fill = group)) +
  geom_col() + coord_flip(ylim = c(3.8, 4.5)) +
  scale_fill_manual(values = pal[c(4, 3)]) +
  labs(title = "Categories by Mean Rating", subtitle = "Axis starts at 3.8; rated apps only",
       x = NULL, y = "Mean rating", fill = NULL)
ggsave_show("plots/09_gg_category_rating.png", g5, width = 9, height = 6.5, dpi = 150)

# 5.6 Line chart: median installs across size bands
line_df <- apps %>% filter(!is.na(size_bin)) %>% group_by(size_bin) %>%
  summarise(median_installs = median(installs), .groups = "drop")
g6 <- ggplot(line_df, aes(size_bin, median_installs, group = 1)) +
  geom_line(colour = pal[1], linewidth = 1.2) +
  geom_point(colour = pal[3], size = 3) +
  scale_y_continuous(labels = scales::comma) +
  labs(title = "Median Installs Across Size Bands", x = "App size band (MB)", y = "Median installs")
ggsave_show("plots/10_gg_line_sizebin.png", g6, width = 8, height = 5.5, dpi = 150)

# 5.7 Boxplot: log installs by type
g7 <- ggplot(apps, aes(type, log_installs, fill = type)) +
  geom_boxplot(show.legend = FALSE, outlier.alpha = 0.3) +
  scale_fill_manual(values = pal[c(1, 3)]) +
  labs(title = "Installs (log10) by App Type", x = "Type", y = "log10(Installs + 1)")
ggsave_show("plots/11_gg_box_type.png", g7, width = 7, height = 5.5, dpi = 150)

# 5.8 Correlation heatmap
cor_df <- as.data.frame(as.table(cor_matrix))
g8 <- ggplot(cor_df, aes(Var1, Var2, fill = Freq)) +
  geom_tile(colour = "white") +
  geom_text(aes(label = Freq), size = 3.5) +
  scale_fill_gradient2(low = pal[3], mid = "white", high = pal[1], midpoint = 0, limits = c(-1, 1)) +
  labs(title = "Correlation Heatmap", x = NULL, y = NULL, fill = "r") +
  theme(axis.text.x = element_text(angle = 30, hjust = 1))
ggsave_show("plots/12_gg_corr_heatmap.png", g8, width = 8, height = 6.5, dpi = 150)
cat("ggplot2 visuals saved to plots/ (05-12)\n")

# ---- Section 6: Export Results (Data Structures & I/O Lab) ----
cat("\n================ SECTION 6: EXPORT ================\n")
export_cols <- c("app", "category", "cat_group", "type", "content_rating", "rating",
                 "rating_group", "reviews", "installs", "install_tier", "price",
                 "size_mb", "size_bin", "days_since_update", "review_rate",
                 "log_reviews", "log_installs", "is_outlier")
clean_out <- apps[, export_cols]

write.csv(clean_out, "output/playstore_clean.csv", row.names = FALSE)
write.table(desc_stats, "output/descriptive_stats.txt", sep = "\t", row.names = FALSE)
rating_matrix_df <- data.frame(category_group = rownames(rating_matrix), rating_matrix,
                               check.names = FALSE)
write_xlsx(list(
  clean_data     = clean_out,
  descriptive    = desc_stats,
  correlation    = data.frame(variable = rownames(cor_matrix), cor_matrix, check.names = FALSE),
  category_stats = as.data.frame(cat_stats),
  group_x_type   = rating_matrix_df
), "output/analysis_results.xlsx")

check <- read.csv("output/playstore_clean.csv")
cat("Exported rows:", nrow(clean_out), "| Re-read rows:", nrow(check),
    "| Match:", identical(nrow(clean_out), nrow(check)), "\n")
cat("Files in output/:\n"); print(list.files("output"))

# ---- Section 7: Lab Coverage Extras (Labs 2, 3, 5, 6, I/O) ----
cat("\n================ SECTION 7: LAB COVERAGE EXTRAS ================\n")
suppressPackageStartupMessages(library(readxl))

# 7.1 rep(): reshape the rating matrix into long format (Lab 2)
rating_long <- data.frame(
  cat_group = rep(rownames(rating_matrix), times = ncol(rating_matrix)),
  type      = rep(colnames(rating_matrix), each = nrow(rating_matrix)),
  mean_rating = as.vector(rating_matrix)
)
cat("Matrix reshaped with rep():\n"); print(rating_long)

# 7.2 while loop: smallest size (MB) that covers 90% of apps with known size (Lab 3)
size_limit <- 5
known_size <- apps$size_mb[!is.na(apps$size_mb)]
while (mean(known_size <= size_limit) < 0.90) {
  size_limit <- size_limit + 1
}
cat("\n90% of apps with a known size are at or below", size_limit, "MB\n")

# 7.3 repeat loop: price needed to cover 75% of paid apps (Lab 3)
paid_prices <- apps$price[apps$type == "Paid"]
budget <- 0.5
repeat {
  share <- mean(paid_prices <= budget)
  if (share >= 0.75) break
  budget <- budget + 0.5
}
cat("A budget of $", budget, "buys", round(share * 100, 1), "% of paid apps\n")

# 7.4 aggregate() grouped statistics (Lab 5)
cat("\nMedian installs by content rating (aggregate):\n")
print(aggregate(installs ~ content_rating, data = apps, FUN = median))
cat("\nMean rating by category group x type (aggregate):\n")
agg2 <- aggregate(rating ~ cat_group + type, data = apps, FUN = mean)
agg2$rating <- round(agg2$rating, 3)
print(agg2)

# 7.5 pairs() scatterplot matrix (Lab 5)
set.seed(42)
pair_sample <- apps[sample(nrow(apps), 2000), c("rating", "log_reviews", "log_installs", "size_mb")]
base_show_save("plots/13_pairs_matrix.png", 1000, 1000, {
  pairs(pair_sample, pch = 20, col = rgb(0.24, 0.35, 0.5, 0.3),
        main = "Scatterplot Matrix (random sample of 2,000 apps)")
})

# 7.6 Histogram + density curve (Lab 6)
g9 <- ggplot(apps, aes(log_installs)) +
  geom_histogram(aes(y = after_stat(density)), bins = 30, fill = pal[2], colour = "white") +
  geom_density(colour = pal[3], linewidth = 1.1) +
  labs(title = "Installs (log10): Histogram with Density Curve",
       x = "log10(Installs + 1)", y = "Density")
ggsave_show("plots/14_gg_hist_density.png", g9, width = 8, height = 5.5, dpi = 150)

# 7.7 Violin plot (Lab 6)
g10 <- ggplot(apps[!is.na(apps$rating), ], aes(type, rating, fill = type)) +
  geom_violin(alpha = 0.8, show.legend = FALSE) +
  geom_boxplot(width = 0.12, fill = "white", outlier.shape = NA) +
  scale_fill_manual(values = pal[c(1, 3)]) +
  labs(title = "Rating Distribution by Type", x = NULL, y = "Rating")
ggsave_show("plots/15_gg_violin_type.png", g10, width = 7, height = 5.5, dpi = 150)

# 7.8 facet_wrap (Lab 6)
g11 <- ggplot(apps[!is.na(apps$rating), ], aes(log_reviews, rating)) +
  geom_point(alpha = 0.2, size = 0.8, colour = pal[1]) +
  geom_smooth(method = "lm", formula = y ~ x, se = FALSE, colour = pal[3]) +
  facet_wrap(~ cat_group) +
  labs(title = "Rating vs Reviews, Faceted by Category Group",
       x = "log10(Reviews + 1)", y = "Rating")
ggsave_show("plots/16_gg_facet_group.png", g11, width = 11, height = 7.5, dpi = 150)

# 7.9 read_excel(): read back the exported workbook (I/O lab)
xlsx_path <- "output/analysis_results.xlsx"
cat("\nSheets in exported workbook:", paste(excel_sheets(xlsx_path), collapse = ", "), "\n")
xl_clean <- read_excel(xlsx_path, sheet = "clean_data")
xl_desc  <- read_excel(xlsx_path, sheet = "descriptive")
cat("clean_data sheet rows:", nrow(xl_clean), "| Match with data frame:",
    nrow(xl_clean) == nrow(clean_out), "\n")
cat("descriptive sheet:\n"); print(xl_desc)

cat("\nTotal plots generated:", length(list.files("plots", pattern = "\\.png$")), "\n")
cat("\n=========== PIPELINE COMPLETE ===========\n")
